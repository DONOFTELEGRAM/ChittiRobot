class DurationLimitError(Exception):
    pass
